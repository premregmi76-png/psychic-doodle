@echo off
setlocal
title WIT Nepal Exam Launcher
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto no_node

echo Starting WIT Nepal Exam Server...
start "WIT Nepal Exam Server" /min cmd /k "cd /d ""%~dp0"" && node server.js"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='http://127.0.0.1:3000'; for($i=0; $i -lt 30; $i++){ try { Invoke-WebRequest -UseBasicParsing -Uri $u -TimeoutSec 1 | Out-Null; Start-Process $u; exit 0 } catch { Start-Sleep -Milliseconds 500 } }; exit 1"
if errorlevel 1 goto server_failed
exit /b 0

:no_node
echo.
echo Node.js is not installed on this computer.
echo The Node.js download page will now open.
echo Install the LTS version, restart the computer, then double-click 1_START_EXAM.bat again.
start "" "https://nodejs.org/en/download"
pause
exit /b 1

:server_failed
echo.
echo The server could not start.
echo Please send a screenshot of the WIT Nepal Exam Server window.
pause
exit /b 1
