@echo off
title Stop WIT Nepal Exam
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":3000" ^| findstr "LISTENING"') do taskkill /PID %%a /F >nul 2>nul
echo WIT Nepal Exam Server stopped.
timeout /t 2 >nul
