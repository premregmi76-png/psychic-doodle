'use strict';

const assert = require('assert');
const { start, hashPassword, verifyPassword, COURSES } = require('./server');

(async () => {
  const stored = hashPassword('sample123');
  assert(verifyPassword('sample123', stored));
  assert(!verifyPassword('wrong', stored));
  assert.strictEqual(COURSES.length, 3);
  const server = await start({ port: 0, host: '127.0.0.1' });
  const address = server.address();
  const base = `http://127.0.0.1:${address.port}`;
  const index = await fetch(base + '/');
  assert.strictEqual(index.status, 200);
  const denied = await fetch(base + '/api/courses');
  assert.strictEqual(denied.status, 401);

  const login = await fetch(base + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'WIT@2083' })
  });
  assert.strictEqual(login.status, 200);
  const cookie = login.headers.get('set-cookie').split(';')[0];
  const courses = await fetch(base + '/api/courses', { headers: { Cookie: cookie } });
  assert.strictEqual(courses.status, 200);
  assert.strictEqual((await courses.json()).courses.length, 3);

  const fixtureName = '__system_test_exam.html';
  const fixture = Buffer.from('<!doctype html><html><body>Test Exam</body></html>').toString('base64');
  const upload = await fetch(base + '/api/admin/upload', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ course: 'nea-electrical-level-5', filename: fixtureName, contentBase64: fixture })
  });
  assert.strictEqual(upload.status, 201);
  const exam = await fetch(base + `/exam/nea-electrical-level-5/${fixtureName}`, { headers: { Cookie: cookie } });
  assert.strictEqual(exam.status, 200);
  assert((await exam.text()).includes('Test Exam'));
  const remove = await fetch(base + `/api/admin/exams?course=nea-electrical-level-5&filename=${fixtureName}`, {
    method: 'DELETE', headers: { Cookie: cookie }
  });
  assert.strictEqual(remove.status, 200);
  await new Promise(resolve => server.close(resolve));
  console.log('All tests passed.');
})().catch(error => { console.error(error); process.exit(1); });
