# यो Exam Portal लाई FREE मा Online राख्ने तरिका (Render.com प्रयोग गरेर)

यो गाइडले तपाईंलाई कम्प्युटर प्रोग्रामिङ थाहा नभए पनि, स्टेप-बाय-स्टेप पालना गर्दा
यो portal इन्टरनेटमा राख्न मद्दत गर्छ। कुनै credit/debit card चाहिँदैन।

कुल समय: करिब १५-२० मिनेट।

---

## चरण १: GitHub मा Account बनाउने

1. https://github.com/signup खोल्नुहोस्।
2. Email, Password, Username राखेर account बनाउनुहोस् (Free छ)।

## चरण २: यो Project GitHub मा राख्ने (Upload गरेर, कुनै command चाहिँदैन)

1. Login भएपछि माथि दायाँतिरको **+** चिन्हमा क्लिक गरी **New repository** छान्नुहोस्।
2. Repository name मा `wit-nepal-exam` जस्तो नाम राख्नुहोस्। **Public** वा **Private**
   जुनसुकै राख्न सकिन्छ (Private राख्दा अझ सुरक्षित हुन्छ)।
3. **Create repository** थिच्नुहोस्।
4. नयाँ खुलेको पेजमा **"uploading an existing file"** भन्ने लिङ्कमा क्लिक गर्नुहोस्।
5. यो ZIP भित्रका **सबै फाइल र फोल्डर** (server.js, package.json, public/, data/,
   exam_files/, render.yaml, आदि सबै) एकैचोटि तानेर (drag-and-drop) त्यहाँ हाल्नुहोस्।
   - `node_modules` भन्ने फोल्डर छैन भने ठीकै छ, त्यो चाहिँदैन।
6. तल **Commit changes** बटनमा क्लिक गर्नुहोस्।

अब तपाईंको कोड GitHub मा सुरक्षित भयो।

## चरण ३: Render.com मा Account बनाउने

1. https://render.com खोल्नुहोस् र **Get Started** मा क्लिक गर्नुहोस्।
2. **"Sign up with GitHub"** छान्नुहोस् (यसले माथिको GitHub account सँगै जोड्छ,
   छुट्टै password राख्नु पर्दैन)।
3. GitHub ले access दिने अनुमति (Authorize) मागे स्वीकार गर्नुहोस्।

## चरण ४: नयाँ Web Service बनाउने

1. Render Dashboard मा **New +** → **Web Service** छान्नुहोस्।
2. आफूले भर्खरै बनाएको `wit-nepal-exam` repository छान्नुहोस् र **Connect** गर्नुहोस्।
3. सेटिङमा यसरी भर्नुहोस्:
   - **Name**: `wit-nepal-exam` (वा जे मन लाग्यो)
   - **Region**: जुनसुकै नजिकको (Singapore भए राम्रो)
   - **Branch**: `main`
   - **Runtime**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
   - **Instance Type**: **Free** छान्नुहोस्।
4. तल **Create Web Service** थिच्नुहोस्।

Render ले अब आफैं भवन (build) गरेर server चलाउँछ। पहिलो पटक २-३ मिनेट लाग्न सक्छ।
सकिएपछि माथि यस्तो देखिन्छ:

```
https://wit-nepal-exam.onrender.com
```

यही Link नै तपाईंको exam portal को Online ठेगाना हो — यो लिंक जोसुकैलाई पठाउन सकिन्छ,
ऊ जुनसुकै ठाउँबाट (Wi-Fi बाहिर, अर्को शहर, अर्को देशबाट समेत) खोल्न सक्छ।

## चरण ५: पहिलो पटक Login गर्ने

- Username: `admin`
- Password: `WIT@2083`

Login भएपछि माथिको **Password** बटनबाट यो password तुरुन्तै फेर्नुहोस्, किनभने यो
सार्वजनिक (public internet) मा उपलब्ध हुनेछ।

---

## ⚠️ धेरै महत्त्वपूर्ण कुरा — FREE प्लानको सीमा

Render को FREE प्लानमा दुई कुरा याद राख्नुहोस्:

1. **१५ मिनेट कोही नखोली बस्यो भने site निदाउँछ (sleep)।** त्यसपछि कसैले लिंक
   खोल्दा पहिलो पटक ३०-६० सेकेन्ड जति ढिलो लोड हुन्छ (यो सामान्य हो, error होइन)।

2. **Admin Dashboard बाट थपेको नयाँ विद्यार्थी वा Upload गरेको नयाँ Exam HTML फाइल
   FREE प्लानमा सधैंलाई सुरक्षित रहँदैन** — किनभने Render को free service ले disk
   मा भएको परिवर्तन स्थायी रूपमा राख्दैन (यो Render कै आधिकारिक सीमा हो, हाम्रो
   कोडको गल्ती होइन)। Server restart वा नयाँ deploy हुँदा ती परिवर्तन हराउन सक्छन्।

   **सुरक्षित तरिका:** नयाँ exam वा विद्यार्थी थप्नु परेमा —
   - `data/users.json` वा `exam_files/...` भित्रको फाइल आफ्नो कम्प्युटरमा
     अपडेट गर्नुहोस्,
   - त्यही अपडेट भएको फाइल फेरि GitHub मा (त्यही ठाउँमा gएर **"Add file → Upload
     files"** ले) अपलोड गर्नुहोस्,
   - Render ले आफैं ती परिवर्तन पत्ता लगाई केही मिनेटमा फेरि deploy गरिदिन्छ।

   यसरी GitHub नै तपाईंको "सधैं सुरक्षित रहने सक्कली प्रति (master copy)" बन्छ।

   *(भविष्यमा Admin Panel बाटै सिधै सधैंको लागि सुरक्षित गर्न चाहनुभयो भने, Render
   को Paid Starter प्लान ($7/महिना) मा "Persistent Disk" थप्न मिल्छ — तर त्यो
   अहिलेको FREE अनुरोधभन्दा बाहिरको कुरा हो।)*

---

## संक्षेपमा

| के गर्ने | कहाँ |
|---|---|
| Code राख्ने | GitHub (free) |
| Server चलाउने | Render.com (free Web Service) |
| Login फेर्ने ठाउँ | Admin → Password बटन |
| नयाँ exam/student थप्दा सधैंलाई बचाउन | GitHub मै फाइल अपडेट गरेर फेरि upload |

समस्या आए Render Dashboard को **Logs** ट्याबमा राता रंगको error हेरेर के भएको
थाहा पाउन सकिन्छ, वा यो च्याटमा फेरि सोध्नुहोस्।
