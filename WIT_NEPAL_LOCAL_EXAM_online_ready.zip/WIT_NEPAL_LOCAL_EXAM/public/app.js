'use strict';

const $ = selector => document.querySelector(selector);
const state = { user: null, courses: [] };
const courseNames = {
  'nea-electrical-level-7': 'NEA 7',
  'nea-electrical-level-5': 'NEA 5',
  'rbb-it-level-5': 'RBB IT 5'
};

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.error || 'समस्या आयो।'), { status: response.status });
  return data;
}

function showMessage(element, text, isError = false) {
  element.textContent = text;
  element.classList.remove('hidden', 'error');
  if (isError) element.classList.add('error');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
}

function formatDate(value) {
  return new Date(value).toLocaleDateString('ne-NP', { year: 'numeric', month: 'short', day: 'numeric' });
}

function showLogin() {
  $('#loginView').classList.remove('hidden');
  $('#dashboardView').classList.add('hidden');
  $('#topbar').classList.add('hidden');
}

async function showDashboard(user) {
  state.user = user;
  $('#loginView').classList.add('hidden');
  $('#dashboardView').classList.remove('hidden');
  $('#topbar').classList.remove('hidden');
  $('#userLabel').textContent = `${user.name} (${user.role === 'admin' ? 'Admin' : user.username})`;
  $('#welcomeTitle').textContent = `स्वागतम्, ${user.name}!`;
  $('#dateChip').textContent = new Date().toLocaleDateString('ne-NP', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  $('#passwordNotice').classList.toggle('hidden', !user.mustChangePassword);
  $('#adminPanel').classList.toggle('hidden', user.role !== 'admin');
  await loadCourses();
  if (user.role === 'admin') await loadStudents();
}

async function loadCourses() {
  const data = await api('/api/courses');
  state.courses = data.courses;
  $('#courseGrid').innerHTML = data.courses.map(course => {
    const exams = course.exams.length ? course.exams.map(exam => `
      <div class="exam-item">
        <a target="_blank" rel="noopener" href="/exam/${encodeURIComponent(course.id)}/${encodeURIComponent(exam.filename)}">${escapeHtml(exam.title)}<small>अपडेट: ${formatDate(exam.updatedAt)}</small></a>
        <div><a class="open-badge" target="_blank" rel="noopener" href="/exam/${encodeURIComponent(course.id)}/${encodeURIComponent(exam.filename)}">खोल्नुहोस्</a>${state.user.role === 'admin' ? `<button class="danger delete-exam" data-course="${course.id}" data-file="${escapeHtml(exam.filename)}" title="Delete">×</button>` : ''}</div>
      </div>`).join('') : '<div class="empty">अहिलेसम्म परीक्षा राखिएको छैन।</div>';
    return `<article class="course-card"><div class="course-title"><div class="course-icon">${course.icon}</div><div><h2>${escapeHtml(course.name)}</h2><small>${course.exams.length} परीक्षा उपलब्ध</small></div></div><div class="exam-list">${exams}</div></article>`;
  }).join('');
  document.querySelectorAll('.delete-exam').forEach(button => button.addEventListener('click', deleteExam));
}

async function loadStudents() {
  const { students } = await api('/api/admin/students');
  $('#studentTable').innerHTML = students.length ? `<table><thead><tr><th>नाम</th><th>Username</th><th>Course</th><th></th></tr></thead><tbody>${students.map(student => `<tr><td>${escapeHtml(student.name)}</td><td>${escapeHtml(student.username)}</td><td><div class="course-tags">${student.courses.map(id => `<span>${courseNames[id] || id}</span>`).join('')}</div></td><td><button class="danger delete-student" data-user="${escapeHtml(student.username)}">हटाउनुहोस्</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty">विद्यार्थी छैनन्।</div>';
  document.querySelectorAll('.delete-student').forEach(button => button.addEventListener('click', deleteStudent));
}

$('#loginForm').addEventListener('submit', async event => {
  event.preventDefault();
  $('#loginError').classList.add('hidden');
  try {
    const { user } = await api('/api/login', { method: 'POST', body: JSON.stringify({ username: $('#loginUsername').value, password: $('#loginPassword').value }) });
    $('#loginForm').reset();
    await showDashboard(user);
  } catch (error) { showMessage($('#loginError'), error.message, true); }
});

$('#logoutBtn').addEventListener('click', async () => { await api('/api/logout', { method: 'POST' }); state.user = null; showLogin(); });

$('#studentForm').addEventListener('submit', async event => {
  event.preventDefault();
  const message = $('#studentMessage');
  message.classList.add('hidden');
  const courses = [...event.currentTarget.querySelectorAll('input[type=checkbox]:checked')].map(input => input.value);
  try {
    await api('/api/admin/students', { method: 'POST', body: JSON.stringify({ name: $('#studentName').value, username: $('#studentUsername').value, password: $('#studentPassword').value, courses }) });
    event.currentTarget.reset();
    showMessage(message, 'विद्यार्थी सफलतापूर्वक थपियो।');
    await loadStudents();
  } catch (error) { showMessage(message, error.message, true); }
});

$('#uploadForm').addEventListener('submit', async event => {
  event.preventDefault();
  const message = $('#uploadMessage');
  message.classList.add('hidden');
  const file = $('#examFile').files[0];
  if (!file) return;
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    let binary = '';
    const chunk = 0x8000;
    for (let index = 0; index < bytes.length; index += chunk) binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
    await api('/api/admin/upload', { method: 'POST', body: JSON.stringify({ course: $('#uploadCourse').value, filename: file.name, contentBase64: btoa(binary) }) });
    event.currentTarget.reset();
    showMessage(message, 'HTML exam सफलतापूर्वक upload भयो।');
    await loadCourses();
  } catch (error) { showMessage(message, error.message, true); }
});

async function deleteStudent(event) {
  const username = event.currentTarget.dataset.user;
  if (!confirm(`${username} लाई हटाउने हो?`)) return;
  await api(`/api/admin/students/${encodeURIComponent(username)}`, { method: 'DELETE' });
  await loadStudents();
}

async function deleteExam(event) {
  const { course, file } = event.currentTarget.dataset;
  if (!confirm(`${file} हटाउने हो?`)) return;
  await api(`/api/admin/exams?course=${encodeURIComponent(course)}&filename=${encodeURIComponent(file)}`, { method: 'DELETE' });
  await loadCourses();
}

$('#passwordBtn').addEventListener('click', () => { $('#passwordForm').reset(); $('#passwordMessage').classList.add('hidden'); $('#passwordDialog').showModal(); });
$('#passwordForm').addEventListener('submit', async event => {
  event.preventDefault();
  const message = $('#passwordMessage');
  message.classList.add('hidden');
  try {
    await api('/api/change-password', { method: 'POST', body: JSON.stringify({ currentPassword: $('#currentPassword').value, newPassword: $('#newPassword').value }) });
    showMessage(message, 'Password परिवर्तन भयो।');
    $('#passwordNotice').classList.add('hidden');
    setTimeout(() => $('#passwordDialog').close(), 900);
  } catch (error) { showMessage(message, error.message, true); }
});

(async function init() {
  try { const { user } = await api('/api/me'); await showDashboard(user); }
  catch { showLogin(); }
})();
