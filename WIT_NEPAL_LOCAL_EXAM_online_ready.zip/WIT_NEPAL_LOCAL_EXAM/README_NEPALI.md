# WIT Nepal Local Exam Platform

यो localhost मा चल्ने course-wise HTML exam portal हो। विद्यार्थीले login गरेपछि आफूलाई अनुमति भएको course का exam मात्र खोल्न सक्छ।

## Course

- NEA Electrical Level 7
- NEA Electrical Level 5
- RBB IT Level 5

## Windows मा चलाउने

1. कम्प्युटरमा Node.js LTS install गर्नुहोस्: https://nodejs.org
2. ZIP फाइलमा सिधै नचलाउनुहोस्—पहिले **Extract All** गर्नुहोस्।
3. Extract भएको folder भित्रको `1_START_EXAM.bat` मा double-click गर्नुहोस्।
4. Server तयार भएपछि Chrome मा `http://127.0.0.1:3000` आफैँ खुल्छ।

यदि Windows ले सुरक्षा warning देखायो भने **More info → Run anyway** गर्नुहोस्। Server बन्द गर्न `2_STOP_EXAM.bat` चलाउनुहोस्।

## सुरुको Login

- Admin username: `admin`
- Admin password: `WIT@2083`
- Demo student username: `student1`
- Demo student password: `123456`

पहिलो login पछि माथिको **Password** button बाट Admin password परिवर्तन गर्नुहोस्।

## नयाँ HTML Exam राख्ने

Admin login गर्नुहोस् → **HTML Exam Upload** मा course छान्नुहोस् → आफ्नो `.html` फाइल छान्नुहोस् → Upload गर्नुहोस्।

Exam लाई क्रम मिलाएर देखाउन filename यसरी राख्नु राम्रो हुन्छ:

- `Week_01.html`
- `Week_02.html`
- `Week_03.html`

वैकल्पिक रूपमा HTML फाइल सिधै यी folder मा राखेर server पुनः load गर्न सकिन्छ:

- `exam_files/nea-electrical-level-7/`
- `exam_files/nea-electrical-level-5/`
- `exam_files/rbb-it-level-5/`

## नयाँ विद्यार्थी थप्ने

Admin Dashboard को **नयाँ विद्यार्थी थप्नुहोस्** भागमा नाम, username, password र उसले पढ्ने course छान्नुहोस्। एउटै विद्यार्थीलाई एकभन्दा बढी course दिन सकिन्छ।

## एउटै Wi-Fi बाट विद्यार्थीले खोल्ने

Server चल्ने कम्प्युटरमा Command Prompt खोलेर `ipconfig` लेख्नुहोस्। त्यहाँ देखिएको IPv4 Address उदाहरणका लागि `192.168.1.10` भए विद्यार्थीले एउटै Wi-Fi बाट:

`http://192.168.1.10:3000`

खोल्न सक्छन्। Windows Firewall ले अनुमति मागेमा **Private networks** मा Allow गर्नुहोस्।

## महत्त्वपूर्ण

- `data/users.json` मा विद्यार्थीको विवरण सुरक्षित हुन्छ; यो फाइल delete नगर्नुहोस्।
- Password plain text मा होइन, सुरक्षित hash को रूपमा राखिन्छ।
- Server restart भएपछि पहिले खुलेका login session बन्द हुन्छन्; फेरि login गर्नुपर्छ।
- Localhost/LAN बाहिर घरबाट खोल्न online hosting वा VPN/tunnel चाहिन्छ।
