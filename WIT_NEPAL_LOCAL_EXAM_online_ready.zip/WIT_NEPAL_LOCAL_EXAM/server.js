'use strict';

const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const EXAMS_DIR = path.join(ROOT, 'exam_files');
const PORT = Number(process.env.PORT || process.env.WIT_PORT || 3000);
const HOST = process.env.WIT_HOST || '0.0.0.0';
const MAX_BODY = 25 * 1024 * 1024;

const COURSES = [
  { id: 'nea-electrical-level-7', name: 'NEA Electrical Level 7', short: 'NEA 7', icon: '⚡' },
  { id: 'nea-electrical-level-5', name: 'NEA Electrical Level 5', short: 'NEA 5', icon: '🔌' },
  { id: 'rbb-it-level-5', name: 'RBB IT Level 5', short: 'RBB IT 5', icon: '💻' }
];

const sessions = new Map();

function courseById(id) {
  return COURSES.find(course => course.id === id);
}

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  try {
    const [salt, savedHex] = String(stored).split(':');
    const calculated = crypto.scryptSync(password, salt, 64);
    const saved = Buffer.from(savedHex, 'hex');
    return saved.length === calculated.length && crypto.timingSafeEqual(saved, calculated);
  } catch {
    return false;
  }
}

async function ensureStorage() {
  await fsp.mkdir(DATA_DIR, { recursive: true });
  await fsp.mkdir(EXAMS_DIR, { recursive: true });
  await Promise.all(COURSES.map(course => fsp.mkdir(path.join(EXAMS_DIR, course.id), { recursive: true })));
  try {
    await fsp.access(USERS_FILE);
  } catch {
    const initialUsers = [
      {
        username: 'admin',
        name: 'WIT Nepal Admin',
        role: 'admin',
        passwordHash: hashPassword('WIT@2083'),
        courses: COURSES.map(course => course.id),
        mustChangePassword: true
      },
      {
        username: 'student1',
        name: 'Demo Student',
        role: 'student',
        passwordHash: hashPassword('123456'),
        courses: COURSES.map(course => course.id),
        mustChangePassword: false
      }
    ];
    await writeUsers(initialUsers);
  }
}

async function readUsers() {
  return JSON.parse(await fsp.readFile(USERS_FILE, 'utf8'));
}

async function writeUsers(users) {
  const temp = `${USERS_FILE}.tmp`;
  await fsp.writeFile(temp, JSON.stringify(users, null, 2), 'utf8');
  await fsp.rename(temp, USERS_FILE);
}

function parseCookies(req) {
  const cookies = {};
  String(req.headers.cookie || '').split(';').forEach(part => {
    const index = part.indexOf('=');
    if (index > -1) cookies[part.slice(0, index).trim()] = decodeURIComponent(part.slice(index + 1).trim());
  });
  return cookies;
}

async function currentUser(req) {
  const token = parseCookies(req).wit_session;
  const session = token && sessions.get(token);
  if (!session || session.expiresAt < Date.now()) {
    if (token) sessions.delete(token);
    return null;
  }
  const users = await readUsers();
  return users.find(user => user.username === session.username) || null;
}

function createSession(username) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { username, expiresAt: Date.now() + 12 * 60 * 60 * 1000 });
  return token;
}

function sendJson(res, status, body, extraHeaders = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extraHeaders });
  res.end(JSON.stringify(body));
}

function sendError(res, status, message) {
  sendJson(res, status, { error: message });
}

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) throw Object.assign(new Error('फाइल वा अनुरोध धेरै ठूलो भयो।'), { status: 413 });
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw Object.assign(new Error('अनुरोध बुझ्न सकिएन।'), { status: 400 });
  }
}

function safeExamName(name) {
  const base = path.basename(String(name || '')).replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').trim();
  if (!base || !base.toLowerCase().endsWith('.html')) return null;
  return base.slice(0, 180);
}

function examTitle(filename) {
  return filename.replace(/\.html$/i, '').replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim();
}

async function listExams(courseId) {
  const dir = path.join(EXAMS_DIR, courseId);
  const entries = await fsp.readdir(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.toLowerCase().endsWith('.html')) continue;
    const stat = await fsp.stat(path.join(dir, entry.name));
    files.push({ filename: entry.name, title: examTitle(entry.name), updatedAt: stat.mtimeMs });
  }
  return files.sort((a, b) => b.updatedAt - a.updatedAt || a.filename.localeCompare(b.filename, undefined, { numeric: true }));
}

function userCanAccess(user, courseId) {
  return user && (user.role === 'admin' || (Array.isArray(user.courses) && user.courses.includes(courseId)));
}

function publicUser(user) {
  return {
    username: user.username,
    name: user.name,
    role: user.role,
    courses: user.courses || [],
    mustChangePassword: Boolean(user.mustChangePassword)
  };
}

async function serveStatic(res, filename, contentType) {
  try {
    const content = await fsp.readFile(path.join(PUBLIC_DIR, filename));
    res.writeHead(200, { 'Content-Type': contentType, 'Cache-Control': 'no-cache' });
    res.end(content);
  } catch {
    res.writeHead(404);
    res.end('Not found');
  }
}

async function handleApi(req, res, url) {
  if (req.method === 'POST' && url.pathname === '/api/login') {
    const body = await readJson(req);
    const username = String(body.username || '').trim().toLowerCase();
    const users = await readUsers();
    const user = users.find(item => item.username === username);
    if (!user || !verifyPassword(String(body.password || ''), user.passwordHash)) {
      return sendError(res, 401, 'Username वा password मिलेन।');
    }
    const token = createSession(user.username);
    return sendJson(res, 200, { user: publicUser(user) }, {
      'Set-Cookie': `wit_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200`
    });
  }

  if (req.method === 'POST' && url.pathname === '/api/logout') {
    const token = parseCookies(req).wit_session;
    if (token) sessions.delete(token);
    return sendJson(res, 200, { ok: true }, { 'Set-Cookie': 'wit_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
  }

  const user = await currentUser(req);
  if (!user) return sendError(res, 401, 'पहिले login गर्नुहोस्।');

  if (req.method === 'GET' && url.pathname === '/api/me') {
    return sendJson(res, 200, { user: publicUser(user) });
  }

  if (req.method === 'GET' && url.pathname === '/api/courses') {
    const available = COURSES.filter(course => userCanAccess(user, course.id));
    const courses = await Promise.all(available.map(async course => ({ ...course, exams: await listExams(course.id) })));
    return sendJson(res, 200, { courses });
  }

  if (req.method === 'POST' && url.pathname === '/api/change-password') {
    const body = await readJson(req);
    const newPassword = String(body.newPassword || '');
    if (!verifyPassword(String(body.currentPassword || ''), user.passwordHash)) return sendError(res, 400, 'हालको password मिलेन।');
    if (newPassword.length < 6) return sendError(res, 400, 'नयाँ password कम्तीमा ६ अक्षरको हुनुपर्छ।');
    const users = await readUsers();
    const index = users.findIndex(item => item.username === user.username);
    users[index].passwordHash = hashPassword(newPassword);
    users[index].mustChangePassword = false;
    await writeUsers(users);
    return sendJson(res, 200, { ok: true });
  }

  if (!url.pathname.startsWith('/api/admin/')) return sendError(res, 404, 'ठेगाना भेटिएन।');
  if (user.role !== 'admin') return sendError(res, 403, 'Admin अनुमति आवश्यक छ।');

  if (req.method === 'GET' && url.pathname === '/api/admin/students') {
    const users = await readUsers();
    return sendJson(res, 200, { students: users.filter(item => item.role === 'student').map(publicUser) });
  }

  if (req.method === 'POST' && url.pathname === '/api/admin/students') {
    const body = await readJson(req);
    const username = String(body.username || '').trim().toLowerCase();
    const name = String(body.name || '').trim();
    const password = String(body.password || '');
    const courses = Array.isArray(body.courses) ? [...new Set(body.courses.filter(id => courseById(id)))] : [];
    if (!/^[a-z0-9._-]{3,40}$/.test(username)) return sendError(res, 400, 'Username ३–४० अक्षरको English letter/number हुनुपर्छ।');
    if (!name) return sendError(res, 400, 'विद्यार्थीको नाम आवश्यक छ।');
    if (password.length < 6) return sendError(res, 400, 'Password कम्तीमा ६ अक्षरको हुनुपर्छ।');
    if (!courses.length) return sendError(res, 400, 'कम्तीमा एउटा course छान्नुहोस्।');
    const users = await readUsers();
    if (users.some(item => item.username === username)) return sendError(res, 409, 'यो username पहिले नै प्रयोग भएको छ।');
    users.push({ username, name, role: 'student', passwordHash: hashPassword(password), courses, mustChangePassword: false });
    await writeUsers(users);
    return sendJson(res, 201, { ok: true });
  }

  if (req.method === 'DELETE' && url.pathname.startsWith('/api/admin/students/')) {
    const username = decodeURIComponent(url.pathname.slice('/api/admin/students/'.length)).toLowerCase();
    const users = await readUsers();
    const filtered = users.filter(item => !(item.role === 'student' && item.username === username));
    if (filtered.length === users.length) return sendError(res, 404, 'विद्यार्थी भेटिएन।');
    await writeUsers(filtered);
    return sendJson(res, 200, { ok: true });
  }

  if (req.method === 'POST' && url.pathname === '/api/admin/upload') {
    const body = await readJson(req);
    const course = courseById(body.course);
    const filename = safeExamName(body.filename);
    if (!course || !filename) return sendError(res, 400, 'Course वा HTML filename ठीक छैन।');
    let content;
    try { content = Buffer.from(String(body.contentBase64 || ''), 'base64'); } catch { return sendError(res, 400, 'फाइल पढ्न सकिएन।'); }
    const beginning = content.subarray(0, 500).toString('utf8').toLowerCase();
    if (!content.length || (!beginning.includes('<!doctype html') && !beginning.includes('<html'))) return sendError(res, 400, 'कृपया सही HTML फाइल मात्र upload गर्नुहोस्।');
    await fsp.writeFile(path.join(EXAMS_DIR, course.id, filename), content);
    return sendJson(res, 201, { ok: true, filename });
  }

  if (req.method === 'DELETE' && url.pathname === '/api/admin/exams') {
    const course = courseById(url.searchParams.get('course'));
    const filename = safeExamName(url.searchParams.get('filename'));
    if (!course || !filename) return sendError(res, 400, 'Course वा filename ठीक छैन।');
    try { await fsp.unlink(path.join(EXAMS_DIR, course.id, filename)); }
    catch (error) { if (error.code === 'ENOENT') return sendError(res, 404, 'Exam भेटिएन।'); throw error; }
    return sendJson(res, 200, { ok: true });
  }

  return sendError(res, 404, 'ठेगाना भेटिएन।');
}

async function handler(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);

    if (req.method === 'GET' && url.pathname.startsWith('/exam/')) {
      const parts = url.pathname.split('/').filter(Boolean);
      if (parts.length !== 3) return sendError(res, 404, 'Exam भेटिएन।');
      const courseId = decodeURIComponent(parts[1]);
      const filename = safeExamName(decodeURIComponent(parts[2]));
      const user = await currentUser(req);
      if (!user) { res.writeHead(302, { Location: '/' }); return res.end(); }
      if (!courseById(courseId) || !filename || !userCanAccess(user, courseId)) return sendError(res, 403, 'यो exam खोल्ने अनुमति छैन।');
      try {
        const content = await fsp.readFile(path.join(EXAMS_DIR, courseId, filename));
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'no-store',
          'Content-Security-Policy': "frame-ancestors 'self'"
        });
        return res.end(content);
      } catch { return sendError(res, 404, 'Exam फाइल भेटिएन।'); }
    }

    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) return serveStatic(res, 'index.html', 'text/html; charset=utf-8');
    if (req.method === 'GET' && url.pathname === '/style.css') return serveStatic(res, 'style.css', 'text/css; charset=utf-8');
    if (req.method === 'GET' && url.pathname === '/app.js') return serveStatic(res, 'app.js', 'application/javascript; charset=utf-8');
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  } catch (error) {
    console.error(error);
    sendError(res, error.status || 500, error.status ? error.message : 'Server मा समस्या आयो।');
  }
}

async function start(options = {}) {
  await ensureStorage();
  const listenPort = options.port ?? PORT;
  const listenHost = options.host ?? HOST;
  const server = http.createServer(handler);
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(listenPort, listenHost, resolve);
  });
  const actualPort = server.address().port;
  console.log(`WIT Nepal Local Exam: http://localhost:${actualPort}`);
  console.log('Admin username: admin');
  return server;
}

if (require.main === module) start().catch(error => { console.error(error); process.exit(1); });

module.exports = { start, COURSES, hashPassword, verifyPassword };
